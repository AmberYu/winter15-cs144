Ebay Database - Project 3
02/12/2015

Team: FlyingKoala
Member: Guangli Wu, 904363455, wuguangli@ucla.edu
        Jingzhi Yu, 604514516, yujingzhi91@gmail.com



----------------------------
1. Keyword Search
----------------------------
We create index for item name, category, description and union of these three fields as they are most likely searched by users. And they are required by the BasicSearch and Spatial Search.

----------------------------
2. Spatial Search
----------------------------
Created MySQL index for Location.