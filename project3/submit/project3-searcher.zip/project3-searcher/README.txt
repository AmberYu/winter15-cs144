Ebay Database - Project 3
02/12/2015

Team: FlyingKoala
Member: Guangli Wu, 904363455, wuguangli@ucla.edu
        Jingzhi Yu, 604514516, yujingzhi91@gmail.com
